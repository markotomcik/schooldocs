pravdepodobnost_mutacie=30
povodnaDNA="AGCGTTGACCCATGTGGGCACGAGTGTACCCTTAGA"
novaDNA=""
zmena=0
# tu doplňte chýbajúci program
# ...
# tu pokračuje program program
print(f'Pôvodná DNA: {povodnaDNA}')
print(f'Nová DNA: {novaDNA}')
print(f'Mutácia prebehla na {zmena} nukleotidoch z celkového počtu {len(povodnaDNA)}')
            
