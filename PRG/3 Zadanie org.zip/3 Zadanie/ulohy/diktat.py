diktat=["syn","dym","bicykel","rizoto","ryža","písomka"]
pocet_spravnych=0
# tu doplňte pokračovanie programu
# ...
# tu pokračuje program
print(f'Výsledok: {pocet_spravnych} správne z {len(diktat)}.')
        
    
    
    
