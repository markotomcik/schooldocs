import turtle
farba=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F']
tabula=turtle.Screen()
pero=turtle.Turtle()
pero.hideturtle()
pero.width(5)
for strana in range(4):
    pero.color('#13A07D')
    pero.forward(50)
    pero.right(90)
tabula.mainloop()
