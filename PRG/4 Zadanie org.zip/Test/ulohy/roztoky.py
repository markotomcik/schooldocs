vzorky=[3,7,5,6,8,4]
vysledky=['_', '_','_','_','_','_']
print('pH analyzovaných vzoriek a výsledky analýzy:')
print(vzorky)
print(vysledky)
